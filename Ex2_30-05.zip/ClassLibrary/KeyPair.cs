﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary
{
    public class KeyPair : IComparable
    {
        private string movieName { get; set; }
        private int movieYear { get; set; }
        public KeyPair(string name , int year)
        {
            movieName = name;
            movieYear = year;
        }
        public int CompareTo(object obj)
        {
            if (!(obj is KeyPair mp))
            {
                throw new ArgumentException("compareTo must get KeyPair");
            }
            int ret = this.movieYear.CompareTo(mp.movieYear);
            if (ret != 0) return ret;
            return this.movieName.CompareTo(mp.movieName);
        }
        public override bool Equals(object obj)
        {
            return movieName.Equals(((KeyPair)obj).movieName) && movieYear.Equals(((KeyPair)obj).movieYear);
        }
    }
}
